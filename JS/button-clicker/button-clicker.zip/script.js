function login_button(element) {
    element.innerText = "Logout";
}

function remove_add_def_button(element) {
    element.remove();
}

function like_def() {
    alert("Ninja was liked");
}